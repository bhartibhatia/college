package college;


public class College
{

    
    public static void main(String[] args)
           {
               ExamSystem e=new ExamSystem();
               e.setVisible(true);
       e.setSize(1900,700);
     
      
    }
    
}
